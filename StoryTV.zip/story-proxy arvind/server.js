const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

// ============================================================
// 🔥 SECRET KEY
// ============================================================

const SECRET_KEY = 'LEGEND_2026_SECRET';

// ============================================================
// 🔥 NEW JWT TOKEN
// ============================================================

const JWT_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJjcmVhdGVkRGF0ZSI6IjIwMjUtMTItMDIgMDI6MTc6NTAuNTQ2Iiwic2Vzc2lvbklkIjoiMTYzMzMzNjE3IiwiZGV2aWNlSWQiOiI3ZjhjMGE1ZDU5MTQ0NDIyMSIsInN1YiI6IjM0ODU1MzkzIiwiZXhwIjoxNzgzMTUzMTAzfQ.kkYEgiwTFlIM1hB71ypFf1ewf_JGgUd8OeAo6FolnW0';

const tokenPayload = JSON.parse(Buffer.from(JWT_TOKEN.split('.')[1], 'base64').toString());

const IDENTITY = {
    userId: tokenPayload.sub || 'Arvind',
    deviceId: tokenPayload.deviceId || '7f8c0a5d591444221',
    sessionId: tokenPayload.sessionId || '163333617',
    jwt: JWT_TOKEN,
    ip: '103.147.66.28',
    userAgent: 'Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36'
};

// ============================================================
// 🔥 GLOBAL: Last selected language (in-memory)
// ============================================================

let LAST_SELECTED_LANG = 2;

const LANG_CODE_MAP = {
    2: 'hi',
    6: 'te',
    7: 'ta',
    8: 'kn',
    9: 'ml'
};

const LANG_NAME_MAP = {
    2: 'Hindi',
    6: 'Telugu',
    7: 'Tamil',
    8: 'Kannada',
    9: 'Malayalam'
};

// ============================================================
// 🔥 BLOCK LIST
// ============================================================

const BLOCK_ENDPOINTS = [
    '/analytics/',
    '/userservice/v1/watched',
    '/userservice/v1/watch_history',
    '/userservice/v1/history',
    '/feedservice/v1/shows/watched',
    '/userservice/v1/likes',
    '/userservice/v1/favorites',
    '/userservice/v1/search/query',
    '/userservice/v1/search/history',
    '/userservice/v1/recommendations/user',
    '/userservice/v1/personalization',
    '/userservice/v1/device/info',
    '/userservice/v1/location',
    '/userservice/v1/ip',
    '/userservice/v1/fingerprint',
    '/userservice/v1/feedback',
    '/userservice/v1/rating',
    '/userservice/v1/logs',
    '/userservice/v1/crash',
    '/neuronet/',
    '/greenhorn/',
    '/userservice/v1/logout',
    '/auth/logout',
    '/logout'
];

const BLOCK_KEYWORDS = ['impression', 'heartbeat', 'tracking', 'metrics', 'crash', 'fingerprint', 'neuronet', 'greenhorn'];

function shouldBlock(path) {
    const lp = path.toLowerCase();
    for (const endpoint of BLOCK_ENDPOINTS) {
        if (lp === endpoint || lp.startsWith(endpoint + '/')) return true;
    }
    for (const keyword of BLOCK_KEYWORDS) {
        if (lp.includes(keyword)) return true;
    }
    return false;
}

function getFakeResponse(path) {
    const lp = path.toLowerCase();
    if (lp.includes('neuronet') || lp.includes('greenhorn')) return { success: true, message: "OK" };
    if (lp.includes('watched') || lp.includes('history')) return { success: true, data: [], total: 0 };
    if (lp.includes('likes') || lp.includes('favorites')) return { success: true, data: [], total: 0 };
    if (lp.includes('analytics') || lp.includes('impression')) return { success: true, tracked: false, message: "OK" };
    if (lp.includes('search/query')) return { success: true, queries: [], suggestions: [] };
    if (lp.includes('logout')) return { success: true, message: "Logged out" };
    return { success: true, message: "OK" };
}

// ============================================================
// 🔥 UNAUTHORIZED BLANK ENDPOINTS
// ============================================================

const BLANK_ENDPOINTS = [
    '/feedservice/v1/homepage',
    '/feedservice/v1/home',
    '/feedservice/v2/explore',
    '/feedservice/v1/explore',
    '/feedservice/v1/feed',
    '/feedservice/v1/discover',
    '/feedservice/v1/trending',
    '/feedservice/v1/popular'
];

function shouldBlank(path) {
    const lp = path.toLowerCase();
    for (const endpoint of BLANK_ENDPOINTS) {
        if (lp === endpoint || lp.startsWith(endpoint + '/')) return true;
    }
    return false;
}

function getBlankResponse(path) {
    const lp = path.toLowerCase();

    if (lp.includes('home') || lp.includes('homepage')) {
        return {
            success: true,
            sections: [],
            banners: [],
            carousels: [],
            data: [],
            message: "No content available",
            total: 0
        };
    }

    if (lp.includes('explore') || lp.includes('discover') || lp.includes('feed')) {
        return {
            success: true,
            content: [],
            shows: [],
            videos: [],
            episodes: [],
            categories: [],
            data: [],
            message: "No content available",
            total: 0,
            pageable: { pageNumber: 0, pageSize: 10, totalElements: 0, totalPages: 0 }
        };
    }

    return {
        success: true,
        data: [],
        shows: [],
        videos: [],
        total: 0,
        message: "No content available"
    };
}

// ============================================================
// 🔥 CORS
// ============================================================

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.header('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

// ============================================================
// 🔧 STATUS
// ============================================================

app.get('/proxy-status', (req, res) => {
    res.json({
        status: 'online',
        proxy: true,
        identity: { userId: IDENTITY.userId, deviceId: IDENTITY.deviceId },
        timestamp: new Date().toISOString(),
        lastSelectedLang: LAST_SELECTED_LANG,
        lastSelectedLangName: LANG_NAME_MAP[LAST_SELECTED_LANG] || 'Hindi'
    });
});

// ============================================================
// 🔧 VERIFY APK
// ============================================================

function verifyApk(req) {
    const key = req.headers['x-ayush-key'];
    return key === SECRET_KEY;
}

// ============================================================
// 🔥 HARDCODED 5 LANGUAGES
// ============================================================

app.get('/userservice/v1/languages', (req, res) => {
    console.log(`\n[${new Date().toLocaleTimeString()}] 🌐 HARDCODED 5 LANGUAGES (Selected: ${LANG_NAME_MAP[LAST_SELECTED_LANG]})`);

    const languages = [
        {
            langId: 2,
            title: "Hindi",
            thumbnailUrl: "https://cdn.storytv.asia/ta/lang/test/hindi.webp",
            isPreSelected: LAST_SELECTED_LANG === 2,
            alphabetUrl: LAST_SELECTED_LANG === 2 
                ? "https://cdn.storytv.asia/ta/lang/test/hindi_char_ON.webp"
                : "https://cdn.storytv.asia/ta/lang/test/hindi_char_OFF.webp"
        },
        {
            langId: 6,
            title: "Telugu",
            thumbnailUrl: "https://cdn.storytv.asia/ta/lang/test/telugu.webp",
            isPreSelected: LAST_SELECTED_LANG === 6,
            alphabetUrl: LAST_SELECTED_LANG === 6
                ? "https://cdn.storytv.asia/ta/lang/test/telugu_char_ON.webp"
                : "https://cdn.storytv.asia/ta/lang/test/telugu_char_OFF.webp"
        },
        {
            langId: 7,
            title: "Tamil",
            thumbnailUrl: "https://cdn.storytv.asia/ta/lang/test/tamil.webp",
            isPreSelected: LAST_SELECTED_LANG === 7,
            alphabetUrl: LAST_SELECTED_LANG === 7
                ? "https://cdn.storytv.asia/ta/lang/test/tamil_char_ON.webp"
                : "https://cdn.storytv.asia/ta/lang/test/tamil_char_OFF.webp"
        },
        {
            langId: 8,
            title: "Kannada",
            thumbnailUrl: "https://cdn.storytv.asia/ta/lang/test/kannada.webp",
            isPreSelected: LAST_SELECTED_LANG === 8,
            alphabetUrl: LAST_SELECTED_LANG === 8
                ? "https://cdn.storytv.asia/ta/lang/test/kannada_char_ON.webp"
                : "https://cdn.storytv.asia/ta/lang/test/kannada_char_OFF.webp"
        },
        {
            langId: 9,
            title: "Malayalam",
            thumbnailUrl: "https://cdn.storytv.asia/ta/lang/test/malayalam.webp",
            isPreSelected: LAST_SELECTED_LANG === 9,
            alphabetUrl: LAST_SELECTED_LANG === 9
                ? "https://cdn.storytv.asia/ta/lang/test/malayalam_char_ON.webp"
                : "https://cdn.storytv.asia/ta/lang/test/malayalam_char_OFF.webp"
        }
    ];

    res.json({
        code: 200,
        message: "App Language Data",
        data: { languages }
    });
});

// ============================================================
// 🔥 LANGUAGE SELECT - FORWARD TO REAL API
// ============================================================

app.post('/userservice/v1/language/select', async (req, res) => {
    const selectedLangId = parseInt(req.body?.langId || req.body?.languageId || 2);
    const langName = LANG_NAME_MAP[selectedLangId] || 'Hindi';

    console.log(`\n[${new Date().toLocaleTimeString()}] 🌐 LANGUAGE SELECT: ${langName} (ID: ${selectedLangId})`);

    LAST_SELECTED_LANG = selectedLangId;

    try {
        const targetUrl = 'https://api.storytv.asia/userservice/v1/language/select';

        const headers = {
            'Authorization': `Bearer ${IDENTITY.jwt}`,
            'X-Device-ID': IDENTITY.deviceId,
            'X-Session-ID': IDENTITY.sessionId,
            'X-User-ID': IDENTITY.userId,
            'User-Agent': IDENTITY.userAgent,
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Forwarded-For': IDENTITY.ip,
            'X-Real-IP': IDENTITY.ip,
            'X-Platform': 'android',
            'X-Client-Version': '3.2.1',
            'Host': 'api.storytv.asia'
        };

        const body = {
            langId: selectedLangId,
            languageId: selectedLangId,
            deviceId: IDENTITY.deviceId,
            sessionId: IDENTITY.sessionId,
            userId: IDENTITY.userId
        };

        console.log(`    → Forwarding to real API...`);

        const response = await axios({
            method: 'POST',
            url: targetUrl,
            headers: headers,
            data: body,
            timeout: 10000,
            validateStatus: () => true,
            httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
        });

        console.log(`    ← Real API Response: ${response.status}`);
        console.log(`    → Language saved: ${langName} (ID: ${selectedLangId})`);

        return res.status(response.status).json(response.data);

    } catch (error) {
        console.error(`    ❌ Real API Error: ${error.message}`);
        console.log(`    → Still saved locally: ${langName} (ID: ${selectedLangId})`);

        res.json({
            code: 200,
            success: true,
            message: "User language updated successfully",
            data: {
                languageId: selectedLangId,
                languageName: langName,
                isUpdated: true,
                selected: true
            }
        });
    }
});

// ============================================================
// 🔧 MODIFY RESPONSE
// ============================================================

function modifyResponse(data, isAuthorized) {
    if (!data || typeof data !== 'object') return data;

    let jsonStr = JSON.stringify(data);

    if (!isAuthorized) {
        jsonStr = jsonStr.replace(/premium plan/gi, 'Mod by @indapks');
        jsonStr = jsonStr.replace(/premium benefits/gi, 'Mod by @indapks');
        jsonStr = jsonStr.replace(/view benefits below/gi, 'Mod by @indapks');
        jsonStr = jsonStr.replace(/renew now/gi, 'Mod by @indapks');
        jsonStr = jsonStr.replace(/renew subscription/gi, 'Mod by @indapks');
        jsonStr = jsonStr.replace(/upgrade now/gi, 'Mod by @indapks');
    }

    try {
        return JSON.parse(jsonStr);
    } catch(e) {
        return data;
    }
}

// ============================================================
// 🔥 BUILD TARGET URL WITH LANGUAGE QUERY PARAMS
// ============================================================

function buildTargetUrl(originalPath, langId) {
    const BASE = 'https://api.storytv.asia';
    
    // Separate path and existing query
    let pathOnly = originalPath;
    let existingQuery = '';
    
    const qIndex = originalPath.indexOf('?');
    if (qIndex !== -1) {
        pathOnly = originalPath.substring(0, qIndex);
        existingQuery = originalPath.substring(qIndex + 1);
    }
    
    // Parse existing params
    const params = new URLSearchParams(existingQuery);
    
    // Add language params if not already present
    if (!params.has('langId')) params.set('langId', String(langId));
    if (!params.has('languageId')) params.set('languageId', String(langId));
    
    const queryString = params.toString();
    return queryString ? `${BASE}${pathOnly}?${queryString}` : `${BASE}${pathOnly}`;
}

// ============================================================
// 🔥 MAIN PROXY
// ============================================================

app.use(async (req, res) => {
    const path = req.originalUrl;

    console.log(`\n[${new Date().toLocaleTimeString()}] 📡 ${req.method} ${path}`);

    const isAuthorized = verifyApk(req);
    console.log(`    → Authorized: ${isAuthorized ? 'YES ✅' : 'NO ❌'}`);
    console.log(`    → Current Language: ${LANG_NAME_MAP[LAST_SELECTED_LANG]} (ID: ${LAST_SELECTED_LANG})`);

    if (shouldBlock(path)) {
        console.log(`    🚫 BLOCKED`);
        return res.status(200).json(getFakeResponse(path));
    }

    if (!isAuthorized && shouldBlank(path)) {
        console.log(`    🚫 UNAUTHORIZED BLANK: ${path}`);
        const blank = getBlankResponse(path);
        const modified = modifyResponse(blank, false);
        return res.status(200).json(modified);
    }

    try {
        // 🔥 FIXED: Build FULL URL with language params
        const targetUrl = buildTargetUrl(path, LAST_SELECTED_LANG);

        const langCode = LANG_CODE_MAP[LAST_SELECTED_LANG] || 'hi';

        let headers = {
            'Authorization': `Bearer ${IDENTITY.jwt}`,
            'X-Device-ID': IDENTITY.deviceId,
            'X-Session-ID': IDENTITY.sessionId,
            'X-User-ID': IDENTITY.userId,
            'User-Agent': IDENTITY.userAgent,
            'Accept': 'application/json',
            'Accept-Language': `${langCode}-${langCode.toUpperCase()},${langCode};q=0.9,en;q=0.8`,
            'Accept-Encoding': 'gzip, deflate, br',
            'Content-Type': 'application/json',
            'X-Forwarded-For': IDENTITY.ip,
            'X-Real-IP': IDENTITY.ip,
            'X-Platform': 'android',
            'X-Client-Version': '3.2.1',
            'X-Language-ID': String(LAST_SELECTED_LANG),
            'X-Language-Code': langCode,
            'Cookie': `device_id=${IDENTITY.deviceId}; session_id=${IDENTITY.sessionId}; user_id=${IDENTITY.userId}; lang_id=${LAST_SELECTED_LANG}`,
            'Host': 'api.storytv.asia'
        };

        let body = req.body;
        if (body && typeof body === 'object' && Object.keys(body).length > 0) {
            body = { ...body };
            body.deviceId = IDENTITY.deviceId;
            body.sessionId = IDENTITY.sessionId;
            body.userId = IDENTITY.userId;
            body.langId = LAST_SELECTED_LANG;
            body.languageId = LAST_SELECTED_LANG;
        }

        console.log(`    → URL: ${targetUrl}`);
        console.log(`    → Headers: X-Language-ID=${LAST_SELECTED_LANG}, Accept-Language=${langCode}`);

        const response = await axios({
            method: req.method,
            url: targetUrl,
            headers: headers,
            data: (req.method !== 'GET' && req.method !== 'HEAD') ? body : undefined,
            timeout: 15000,
            validateStatus: () => true,
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            httpsAgent: new (require('https').Agent)({ rejectUnauthorized: false })
        });

        console.log(`    ← Status: ${response.status}`);

        let responseData = response.data;

        if (typeof responseData === 'object' && responseData !== null) {
            responseData = modifyResponse(responseData, isAuthorized);
        }

        Object.entries(response.headers).forEach(([key, value]) => {
            const lowerKey = key.toLowerCase();
            if (!['content-encoding', 'transfer-encoding', 'content-length'].includes(lowerKey)) {
                res.setHeader(key, value);
            }
        });

        res.status(response.status).json(responseData);

    } catch (error) {
        console.error(`    ❌ Error: ${error.message}`);

        const fake = getFakeResponse(path);
        if (fake) {
            console.log(`    🎭 FALLBACK FAKE`);
            return res.status(200).json(fake);
        }

        res.status(502).json({ error: "Proxy Error", message: error.message });
    }
});

// ============================================================
// 🚀 START
// ============================================================

const PORT = 3460;
app.listen(PORT, '127.0.0.1', () => {
    console.log('╔══════════════════════════════════════════════════╗');
    console.log('║     🔒 INDAPKS PROXY ONLINE               ║');
    console.log('║     Domain: story.appsdone.online              ║');
    console.log('║     API: api.storytv.asia                      ║');
    console.log('╠══════════════════════════════════════════════════╣');
    console.log(`║  User:  ${IDENTITY.userId}                       ║`);
    console.log('╠══════════════════════════════════════════════════╣');
    console.log('║  🔥 FIXED:                                      ║');
    console.log('║  ✅ URL bug fixed (was returning path only)    ║');
    console.log('║  ✅ Language select forwards to REAL API        ║');
    console.log('║  ✅ Language sent as query param (?langId=X)    ║');
    console.log('║  ✅ Language sent in Headers + Body             ║');
    console.log('╚══════════════════════════════════════════════════╝');
});